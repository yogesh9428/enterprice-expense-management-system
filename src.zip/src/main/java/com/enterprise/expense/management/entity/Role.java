package com.enterprise.expense.management.entity;

public enum Role {
    EMPLOYEE , MANAGER , ADMIN
}
