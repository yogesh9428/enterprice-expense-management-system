package com.enterprise.expense.management.entity;

public enum ExpenseStatus {
    PENDING, INPROCESS , APPROVED, REJECTED
}
